from setuptools import setup

setup(
    name='lab 11',
    version='',
    packages=['ui', 'utils', 'modules', 'testing'],
    url='',
    license='',
    author='liber',
    author_email='',
    description=''
)
