
    def getCNP(self):